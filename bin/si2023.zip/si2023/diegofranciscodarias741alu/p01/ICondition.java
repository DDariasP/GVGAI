package si2023.diegofranciscodarias741alu.p01;




public interface ICondition {
	
	public Boolean isTrue(World w);

}
