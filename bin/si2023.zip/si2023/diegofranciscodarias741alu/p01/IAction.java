package si2023.diegofranciscodarias741alu.p01;


import ontology.Types.ACTIONS;


public interface IAction {
	
	public ACTIONS doAction(World w);

}
