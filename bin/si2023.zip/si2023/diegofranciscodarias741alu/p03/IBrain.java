package si2023.diegofranciscodarias741alu.p03;

import ontology.Types.ACTIONS;

public interface IBrain {

	public ACTIONS think(AgentWorld89 w);

}
