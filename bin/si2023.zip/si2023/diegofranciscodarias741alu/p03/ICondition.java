package si2023.diegofranciscodarias741alu.p03;

public interface ICondition {

	public Boolean isTrue(AgentWorld89 w);

}
