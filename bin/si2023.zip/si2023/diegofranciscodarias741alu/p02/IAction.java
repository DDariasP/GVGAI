package si2023.diegofranciscodarias741alu.p02;

import ontology.Types.ACTIONS;


public interface IAction {

	public ACTIONS doAction(World89 w);

}
