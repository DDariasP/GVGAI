package si2023.diegofranciscodarias741alu.p02;


public class State1 extends State {
	
	public State1() {
		
		name = "bottomRow";
		action = new LeaveSpawn();
		
	}

}
