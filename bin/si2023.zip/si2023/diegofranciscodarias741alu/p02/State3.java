package si2023.diegofranciscodarias741alu.p02;


public class State3 extends State {
	
	public State3() {
		
		name = "foundVillain";
		action = new CaptureVillain();
		
	}
	
}