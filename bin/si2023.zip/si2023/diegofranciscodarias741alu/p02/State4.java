package si2023.diegofranciscodarias741alu.p02;


public class State4 extends State {
	
	public State4() {
		
		name = "fullBag";
		action = new EmptyBag();
		
	}
	
}