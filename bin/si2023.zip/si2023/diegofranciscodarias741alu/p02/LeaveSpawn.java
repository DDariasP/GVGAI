package si2023.diegofranciscodarias741alu.p02;

import ontology.Types.ACTIONS;


public class LeaveSpawn implements IAction {

	@Override
	public ACTIONS doAction(World89 w) {
		
		return ACTIONS.ACTION_UP;
	}

}
