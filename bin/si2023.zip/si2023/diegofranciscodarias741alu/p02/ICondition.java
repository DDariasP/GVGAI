package si2023.diegofranciscodarias741alu.p02;



public interface ICondition {

	public Boolean isTrue(World89 w);

}
