package si2023.diegofranciscodarias741alu.p02;

public class State2 extends State {
	
	public State2() {
		
		name = "fallingPerson";
		action = new SavePerson();
		
	}
	
}