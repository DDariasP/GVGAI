package si2023.diegofranciscodarias741alu.p02;



public interface IBrain {

	public State trigger(World89 w);

}
